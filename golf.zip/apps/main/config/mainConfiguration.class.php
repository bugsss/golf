<?php

class mainConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
