<?php use_helper('Date') ?>
<?php include_partial( 'index/left_menu', array( "module" => "home" ) ); ?>
    <div class="content">
    	<div class="title"><h5><?php echo __( 'Dashboard' ) ?></h5></div>
    </div>
<script type="text/javascript">
    $(document).ready(function() {
    });
</script>