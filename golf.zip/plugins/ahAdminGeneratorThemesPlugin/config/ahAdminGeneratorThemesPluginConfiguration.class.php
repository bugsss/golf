<?php

/**
 * ahAdminGeneratorThemesPlugin configuration.
 * 
 * @package     ahAdminGeneratorThemesPlugin
 * @subpackage  config
 * @author      Daniel Lohse <info@asapdesign.de>
 */
class ahAdminGeneratorThemesPluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}
